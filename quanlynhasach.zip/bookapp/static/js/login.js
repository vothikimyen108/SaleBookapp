document.querySelector('.img-btn').addEventListener('click', function()
	{
		document.querySelector('.cont').classList.toggle('s-signup')

    document.querySelector('.form').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.form').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("transition", "transform 1.2s ease-in-out");
     document.querySelector('.img-text').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.img-text').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-duration", "1.2s;");
     document.querySelector('.img-btn span').style.setProperty("-webkit-transition", "1.2s ease-in-out");
     document.querySelector('.img-btn span').style.setProperty("transition", "transform 1.2s ");
       document.querySelector('.flaghasacc').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.flaghasacc').style.setProperty("transition", "transform 1.2s ease-in-out");

	}
);
document.querySelector('.noacc').addEventListener('click', function()
	{

	document.querySelector('.cont').classList.toggle('s-signup')
    document.querySelector('.form').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.form').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("transition", "transform 1.2s ease-in-out");
     document.querySelector('.img-text').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.img-text').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-duration", "1.2s;");
     document.querySelector('.img-btn span').style.setProperty("-webkit-transition", "1.2s ease-in-out");
     document.querySelector('.img-btn span').style.setProperty("transition", "transform 1.2s ");
       document.querySelector('.flaghasacc').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.flaghasacc').style.setProperty("transition", "transform 1.2s ease-in-out");
	}
);
document.querySelector('.acc').addEventListener('click', function()
	{
		document.querySelector('.cont').classList.toggle('s-signup')
    document.querySelector('.form').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.form').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.sub-cont').style.setProperty("transition", "transform 1.2s ease-in-out");
     document.querySelector('.img-text').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.img-text').style.setProperty("transition", "transform 1.2s ease-in-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("transition-timing-function", "ease-out");
    document.querySelector('.sign-in').style.setProperty("-webkit-transition-duration", "1.2s;");
     document.querySelector('.img-btn span').style.setProperty("-webkit-transition", "1.2s ease-in-out");
     document.querySelector('.img-btn span').style.setProperty("transition", "transform 1.2s ");
       document.querySelector('.flaghasacc').style.setProperty("-webkit-transition", "1.2s ease-in-out");
    document.querySelector('.flaghasacc').style.setProperty("transition", "transform 1.2s ease-in-out");
	}
);
function now() {

    document.querySelector('.cont').classList.toggle('s-signup')
}
